#!/usr/bin/env bash
set -e

# === EDIT THESE VALUES BEFORE RUNNING ===
GITHUB_USER="YOUR_GITHUB_USERNAME"   # replace with your GitHub username or org
REPO="zero-homeless-initiative-android"
PRIVATE=true                         # set to false for public repo
DEFAULT_BRANCH="main"
# =======================================

ROOT="$REPO"
echo "Creating repository scaffold at ./$ROOT"

# Clean up if exists
rm -rf "$ROOT"
mkdir -p "$ROOT"
cd "$ROOT"

# Initialize git
git init -b "$DEFAULT_BRANCH"

# Basic files
cat > README.md <<'MD'
# Zero Homeless Initiative Android

Mobile client for the Zero Homeless Initiative. Backendless architecture using Firebase Auth, Firestore, and Storage.

See docs/README-SETUP.md for setup and deployment steps.
MD

cat > LICENSE <<'MIT'
MIT License

Copyright (c) 2026 The Zero Homeless Foundation

Permission is hereby granted, free of charge, to any person obtaining a copy...
MIT

cat > .gitignore <<'TXT'
/.gradle/
/build/
/local.properties
*.iml
*.keystore
.env
/.idea/
*.log
TXT

# Minimal repo structure
mkdir -p android-app/app/src/main/java/com/zerohomeless/ui/screens
mkdir -p infra/firebase
mkdir -p docs
mkdir -p .github/workflows

# Sample Android placeholder files
cat > android-app/app/src/main/java/com/zerohomeless/App.kt <<'KT'
package com.zerohomeless

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreSettings

class App : Application() {
  override fun onCreate() {
    super.onCreate()
    FirebaseApp.initializeApp(this)
    FirebaseFirestore.getInstance().firestoreSettings = FirebaseFirestoreSettings.Builder()
      .setPersistenceEnabled(true)
      .build()
  }
}
KT

cat > android-app/app/src/main/java/com/zerohomeless/ui/screens/ProgramsScreen.kt <<'KT'
package com.zerohomeless.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.material.Text
import androidx.compose.runtime.Composable

@Composable
fun ProgramsScreen() {
  Column {
    Text("Zero Homeless Initiative")
    Text("Programs list will appear here")
  }
}
KT

# Firestore rules
cat > infra/firebase/firestore.rules <<'RULES'
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /publicPrograms/{programId} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
    match /users/{userId}/{document=**} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /donations/{donationId} {
      allow create: if request.auth != null;
      allow read: if request.auth != null && (resource.data.userId == request.auth.uid || request.auth.token.admin == true);
    }
    match /exports/{exportId} {
      allow create: if request.auth != null;
      allow read: if request.auth != null && (resource.data.userId == request.auth.uid || request.auth.token.caseworker == true);
      allow delete: if request.auth != null && request.auth.token.admin == true;
    }
  }
}
RULES

# Firebase storage rules
cat > infra/firebase/storage.rules <<'RULES'
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /users/{userId}/uploads/{allPaths=**} {
      allow read: if request.auth != null && request.auth.uid == userId;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    match /public/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.token.admin == true;
    }
  }
}
RULES

# Docs
cat > docs/README-SETUP.md <<'MD'
# Setup Guide

1. Create Firebase project and enable Auth, Firestore, Storage, FCM.
2. Add firebase config to android-app and set google-services.json.
3. Seed publicPrograms via Firebase Console or import script.
4. Create Stripe Payment Links for donations and store links in Firestore.
5. Replace TODO placeholders in infra and .env before production.
MD

# GitHub Actions CI placeholder
cat > .github/workflows/android-ci.yml <<'YML'
name: Android CI
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: 17
      - name: Build
        run: ./gradlew assembleDebug
YML

# Initial commit
git add .
git commit -m "chore: initial scaffold for Zero Homeless Initiative Android"

# Create remote repo using gh CLI if available
if command -v gh >/dev/null 2>&1; then
  echo "Creating remote repository on GitHub as ${GITHUB_USER}/${REPO}"
  if [ "$PRIVATE" = true ]; then
    gh repo create "${GITHUB_USER}/${REPO}" --private --source=. --remote=origin --push
  else
    gh repo create "${GITHUB_USER}/${REPO}" --public --source=. --remote=origin --push
  fi
  echo "Remote created and pushed."
else
  echo "gh CLI not found. To create remote repo manually:"
  echo "  1) Create a new repo on GitHub named ${REPO}"
  echo "  2) git remote add origin git@github.com:${GITHUB_USER}/${REPO}.git"
  echo "  3) git push -u origin ${DEFAULT_BRANCH}"
fi

echo "Repository scaffold created at $(pwd)"
